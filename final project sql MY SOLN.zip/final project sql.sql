create database Netflix_analysis;
use netflix_analysis;

create table genre_details (
genreid varchar(100) primary key,
genre varchar(100)
);

create table netflix_originals (
title varchar(100),
genreid varchar(100),
runtime int,
IMDBScore decimal (3,1),
language varchar(100),
Premiere_date date,
foreign key (genreid) references genre_details(genreid)
);

select * from genre_details;
select * from netflix_originals;

show tables;

q no 1: What are the average IMDb scores for each genre of Netflix Originals?

SELECT g.genre,
       ROUND(AVG(n.IMDBScore), 2) AS Avg_IMDB
FROM netflix_originals n
JOIN genre_details g
ON n.genreid = g.genreid
GROUP BY g.genre;

q no 2 : Which genres have an average IMDb score higher than 7.5?

SELECT g.genre,
       ROUND(AVG(n.IMDBScore), 2) AS Avg_IMDB
FROM netflix_originals n
JOIN genre_details g
ON n.genreid = g.genreid
GROUP BY g.genre
HAVING AVG(n.IMDBScore) > 7.5;

q no 3 : List Netflix Original titles in descending order of their IMDb scores

select title, imdbscore
from netflix_originals
order by imdbscore desc;

q no 4 : Retrieve the top 10 longest Netflix Originals by runtime.

select title, runtime
from netflix_originals
order by runtime desc
limit 10;

q no 5 : Retrieve the titles of Netflix Originals along with their respective genres.

select n.title, g.genre
from netflix_originals n
join genre_details g
on n.genreid = g.genreid;

q no 6 : Rank Netflix Originals based on their IMDb scores within each genre

SELECT N.TITLE, G.GENRE, N.IMDBSCORE,
RANK() OVER (PARTITION BY G.GENRE ORDER BY N.IMDBSCORE DESC) AS GENRE_RANK
FROM netflix_originals n
join genre_details g
on n.genreid = g.genreid;

q no 7 : Which Netflix Originals have IMDb scores higher than the average IMDb score of all titles?

select title, imdbscore
from netflix_originals
where imdbscore > (select avg(imdbscore)from netflix_originals);

q no 8 : How many Netflix Originals are there in each genre?

select g.genre,
count(*) as total_titles
from netflix_originals n
join genre_details g
on n.genreid = g.genreid
group by g.genre;

q no 9 : Which genres have more than 5 Netflix Originals with an IMDb score higher than 8?

select g.genre,
count(*) as high_rated_count
from netflix_originals n
join genre_details g
on n.genreid = g.genreid
where n.imdbscore > 8
group by g.genre
having count(*) > 5;

q no 10 : What are the top 3 genres with the highest average IMDb scores, and how many Netflix Originals do they have?

SELECT g.genre,
       ROUND(AVG(n.IMDBScore), 2) AS Avg_IMDB,
       COUNT(*) AS total_titles
FROM netflix_originals n
JOIN genre_details g
ON n.genreid = g.genreid
GROUP BY g.genre
ORDER BY Avg_IMDB DESC
LIMIT 3;





